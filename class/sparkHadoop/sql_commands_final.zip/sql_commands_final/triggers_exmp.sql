-- triggers 2
-- first example  after update trigger
-- 

-- before update trigger
-- create table product(id int, name varchar(50), cost decimal(7,2)); 
-- insert into product values(1,"Mobile1",12000),(2,"Mobile2",15000),(3,"Mobile3",17000); 
-- select * from product; 
-- BEGIN
-- if new.cost>40000 then
-- signal sqlstate "45000"
-- set message_text="cost is very high"; 
-- endif;
-- END

-- update product set cost=16000 where id=1; 
-- select * from product; 
-- update product set cost=46000 where id=3; this will throw an error cost is very high 

-- before delete trigger 
-- create table emp(emp_id int,hire_date date,salary int); 
-- insert into emp values(1,"2012-01-20",2000),(2,"2013-02-23",3000),(3,"2009-09-12",5000); 
-- select * from emp; 
-- create table backup(id int primary key auto_increment,emp_id int,hire_date date,salary int,Deleted_at timestamp default now()); 
-- go to emp table , click on hammer sign , go to triggers, check before delete trigger option
-- insert into backup(emp_id,hire_date,salary) values(old.emp_id,old.hire_date,old.salary);
-- delete from emp where emp_id=2; 
-- select * from emp; 
-- select * from backup; 

-- after delete trigger; 
-- create table emp_salary(emp_id int,emp_name varchar(50),salary decimal(10,3)); 
-- insert into salary values(1,"ramesh",3000),(2,"suresh",3500),(3,"swathi",4000); 
-- select * from emp_salary; 
-- create table budget(total decimal(10,2)); 
-- insert into budget(total) select sum(salary) from emp_salary; 
-- select * from budget; 


-- go to emp_salary table , creat a after delete trigger 
-- update budget set total=total-old.salary; 
-- select * from emp_salary;
-- delete from emp_salary where emp_id=2; 
 -- select * from budget; 
 
 
 


-- 


