-- tcl commands- commit, rollback, savepoint
-- they work only on dml commands- insert , update and delete
-- they dont work on ddl commands 
-- when working with dml commands, usually the values are stored in hard drive 
-- now if we wnat to make any changes , it is not possible, so use tcl commands instead , they will store the values in buffer/cache memory, 
-- from where you can decide to commit or rollback a transaction (set of comments together is a transaction)
-- when you want to work with tcl commands, you have to say start transaction; 
-- when you are working with dml coomands , autocommit is on usually 
-- but when you say start transaction , autocommit is turned off , gives us the choice if you want to commit or rollback a transaction 
-- create table class(sid int, sname varchar(50), age int, course varchar(50)); 
-- insert into class values(1,"hareesh",26,"MySQL");
-- select * from class; 
-- rollback; 
-- start transaction; 
-- insert into class values(2,"harini",25,"MySQL");
-- insert into class values(3,"ali",24,"Tableau"); 
-- select * from class; 
-- rollback; 
-- start transaction; 
-- insert into class values(2,"harini",25,"MySQL");
-- insert into class values(3,"ali",24,"Tableau");
-- commit; 
-- select * from class; 
-- rollback; 
-- select * from class; (rollback doesnot work)
-- savepoint
-- create table t1(name char(1)); 
-- start transaction; 
-- insert into t1 values("a");
-- insert into t1 values("b");
-- savepoint sb; 
-- insert into t1 values("c");
-- insert into t1 values("d");
-- savepoint sd;
-- insert into t1 values("e");
-- insert into t1 values("f"); 
-- select * from t1; 
-- rollback to sd; 
-- select * from t1; 
-- rollback to sb; 
-- select * from t1; 
-- commit; 
-- select * from t1; 

-- acid properties of tcl commands - atomocity, consistency, isolation. durability
-- if a transaction is following all the acid properties, then it is a good transaction
-- sequence object -- example roll numbers, all the values in roll number column we want to create in a sequence 
-- we dont have to manually eneter values in a sequence, we can use a sequence object 
-- we can use something like auto_increment, it is generally given to primary key
-- drop table class; 
-- create table class(sid int primary key auto_increment, name varchar(50), age int , course varchar(50)); 
-- desc class; 
-- insert into class(name, age, course) values("hareesh", 24, "MySQL"); 
-- insert into class(name, age, course) values("swathi", 25, "MySQL"); 
-- insert into class(name, age, course) values("hari", 26, "MySQL"); 
-- select * from class; 
-- alter table class auto_increment=100; 
-- insert into class(name, age, course) values("teja", 26, "MySQL"); 
-- insert into class(name, age, course) values("obaid", 26, "MySQL"); 
-- delete from class;
-- insert into class(name, age, course) values("obaid", 26, "MySQL");  
-- select * from class; 
-- insert into class(name, age, course) values("swathi", 25, "MySQL"); 
-- insert into class(name, age, course) values("hari", 26, "MySQL"); 
-- truncate table class; 
-- -- insert into class(name, age, course) values("swathi", 25, "MySQL");











